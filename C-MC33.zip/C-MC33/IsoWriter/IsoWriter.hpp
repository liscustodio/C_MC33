#ifndef ISOWRITER_HPP_
#define ISOWRITER_HPP_

#include <fstream>
#include <string>
#include <cmath>


// array with the .raw data
float *data_f = NULL;
short *data_s = NULL;
unsigned char *data_u = NULL;

int data_type = 0;
// size of the data array
int n_data = 0;

// grid dimensions
int size_x = 0;
int size_y = 0;
int size_z = 0;

float sx = 0;
float sy = 0;
float sz = 0;

class isoWriter
{
public:

	static int Write(unsigned nx, unsigned ny, unsigned nz, float sx, float sy, float sz, const std::string fileName)
  {
    std::string isoFileName = fileName + ".iso";
    char* byte;

    std::ofstream fileISO(isoFileName.c_str(), std::ios::out | std::ios::binary);

    if(!fileISO.is_open())
      {
	std::cout << std::endl;
	std::cout << "\tCouldn't create specified file '" << isoFileName;
	std::cout << "'." << std::endl;
	return 1;
      }

    float mnx = 0.0, mny = 0.0, mnz = 0.0, mxx = nx*sx, mxy = ny*sy, mxz = nz*sz;

    byte = reinterpret_cast<char*>(&nx);
    fileISO.write(byte, sizeof(unsigned));

    byte = reinterpret_cast<char*>(&ny);
    fileISO.write(byte, sizeof(unsigned));

    byte = reinterpret_cast<char*>(&nz);
    fileISO.write(byte, sizeof(unsigned));

    byte = reinterpret_cast<char*>(&(mnx));
    fileISO.write(byte, sizeof(float));
    byte = reinterpret_cast<char*>(&(mxx));
    fileISO.write(byte, sizeof(float));
    byte = reinterpret_cast<char*>(&(mny));
    fileISO.write(byte, sizeof(float));
    byte = reinterpret_cast<char*>(&(mxy));
    fileISO.write(byte, sizeof(float));
    byte = reinterpret_cast<char*>(&(mnz));
    fileISO.write(byte, sizeof(float));
    byte = reinterpret_cast<char*>(&(mxz));
    fileISO.write(byte, sizeof(float));

    unsigned i, j, k;
    for(i = 0; i < nx; ++i)
    {
      for(j = 0; j < ny; ++j)
	for(k = 0; k < nz; ++k)
	  {

	    if(data_type == 9)
    	{
    	float value = data_f[i + j * nx + k * nx * ny];
    	byte = reinterpret_cast<char*>(&value);
    	}


	    if(data_type == 2)
    	{
    	float value = data_u[i + j * nx + k * nx * ny];
    	byte = reinterpret_cast<char*>(&value);
    	}


	    if(data_type == 3)
	    	{
	    	float value = data_s[i + j * nx + k * nx * ny];
	    	byte = reinterpret_cast<char*>(&value);
	    	}

	    		fileISO.write(byte, sizeof(float));

	  }

      }

    return 0;
  }

  static char* changeEndianness(char* byte, unsigned size)
  {
    for(int i = 0; i < (int)(size * 0.5); ++i)
      {
	char c;
	c= byte[i];
	byte[i] = byte[size-1-i];
	byte[size-1-i] = c;
      }

    return byte;
  }
};

#endif /* ISOWRITER_HPP_ */
