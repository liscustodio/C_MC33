#include <iostream>
#include <stdio.h>
#include "teem/nrrd.h"
#include "isoWriter.hpp"

using namespace std;




void read_nhdr(char *filename)
{
  char *err;

  /* create a nrrd; at this point this is just an empty container */
  Nrrd *nin = nrrdNew();

  /* read in the nrrd from file */
  if (nrrdLoad(nin, filename, NULL)) {
    err = biffGetDone(NRRD);
    fprintf(stderr, "read_nhdr: trouble reading \"%s\":\n%s", filename, err);
    free(err);
    return;
  }

  /* say something about the array */
  printf("read_nhdr: \"%s\" is a %d-dimensional nrrd of type %d (%s)\n", filename, nin->dim, nin->type,airEnumStr(nrrdType, nin->type));
  printf("read_nhdr: the array contains %d elements, each %d bytes in size\n", (int)nrrdElementNumber(nin), (int)nrrdElementSize(nin));

  size_x = nin->axis[0].size;
  size_y = nin->axis[1].size;
  size_z = nin->axis[2].size;

  sx = nin->axis[0].spacing;
  sy = nin->axis[1].spacing;
  sz = nin->axis[2].spacing;

  int n_data = (int)nrrdElementNumber(nin);

  data_type = nin->type;

  if(data_type == 9)
  {
	  data_f = new float [n_data];
	  memcpy(data_f, nin->data, n_data * sizeof(float));
  }
  if(data_type == 2)
  {
	  data_u = new unsigned char [n_data];
	  memcpy(data_u, nin->data, n_data * sizeof(unsigned char));
  }
  if(data_type == 3)
  {
	  data_s = new short [n_data];
	  memcpy(data_s, nin->data, n_data * sizeof(short));
  }


  nrrdNuke(nin);




  return;
}


int main(int argc, char* argv[])
{

	char *filename;
	char * output;

	if(argc == 3)
		{
			filename = argv[1];
			output = argv[2];

		}
	else
		{
	    std::cout << "Usage: " << argv[0] << "  Filename(.nhdr) IsofileName" << std::endl;
	    return 1;
		}


	read_nhdr(filename);

	isoWriter writer;
	writer.Write(size_x, size_y, size_z,sx,sy, sz, output);


	return 0;
}
