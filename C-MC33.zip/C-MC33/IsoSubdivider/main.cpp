//------------------------------------------------
// MarchingCubes
//------------------------------------------------
//
// MarchingCubes Command Line interface
// Version 0.2 - 12/08/2002
//
// Thomas Lewiner thomas.lewiner@polytechnique.org
// Math Dept, PUC-Rio
//
//________________________________________________
#include <stdio.h>
#include <math.h>
#include "MarchingCubes.h"
#include "IsoWriter.hpp"

#include "defs.h"
#include "fparser.h"


 unsigned char k_f[200];
 float t_f[200];
 float eps = 0.05;
 unsigned char contk = 0;
 unsigned char contj = 0;



enum Axis      { X=0, Y=1, Z=2 };
//_____________________________________________________________________________
// main marching cubes object
MarchingCubes mc ;

// isovalue defining the isosurface
float isoval = 0.0f ;

// original/topological MC switch
int   originalMC = 0 ;

// grid extension
float xmin=-1.0f, xmax=1.0f,  ymin=-1.0f, ymax=1.0f,  zmin=-1.0f, zmax=1.0f ;
// grid size control
int   size_x=50, size_y=50, size_z=50 ;

// loaded iso grid
FILE  *isofile  ;

// implicit formula
char  *formula;

// switch to export iso grid
int  export_iso = 0 ;

//_____________________________________________________________________________

void reading_data()
{
	unsigned char buf[sizeof(float)];
	fread(buf, sizeof(float), 1, isofile);
	size_x = *(int*) buf;
	fread(buf, sizeof(float), 1, isofile);
	size_y = *(int*) buf;
	fread(buf, sizeof(float), 1, isofile);
	size_z = *(int*) buf;

	fread(buf, sizeof(float), 1, isofile);
	xmin = *(float*) buf;
	fread(buf, sizeof(float), 1, isofile);
	xmax = *(float*) buf;
	fread(buf, sizeof(float), 1, isofile);
	ymin = *(float*) buf;
	fread(buf, sizeof(float), 1, isofile);
	ymax = *(float*) buf;
	fread(buf, sizeof(float), 1, isofile);
	zmin = *(float*) buf;
	fread(buf, sizeof(float), 1, isofile);
	zmax = *(float*) buf;

	formula = "i-0";
}

//_____________________________________________________________________________
// run the MC algorithm
bool run()
//-----------------------------------------------------------------------------
{
  if( strlen(formula) <= 0 ) return false ;

  // Init data
  mc.set_resolution( size_x, size_y, size_z ) ;
  mc.init_temps();

  // Parse formula
  FunctionParser fparser ;
  fparser.Parse( (const char*)formula, "x,y,z,c,i" ) ;
  if( fparser.EvalError() )
  {
    printf( "parse error\n" ) ;
    return false ;
  }

  // Fills data structure
  int i,j,k ;
  float val[5], w ;
  float rx = (xmax-xmin) / (size_x - 1) ;
  float ry = (ymax-ymin) / (size_y - 1) ;
  float rz = (zmax-zmin) / (size_z - 1) ;
  unsigned char buf[sizeof(float)] ;
  for( i = 0 ; i < size_x ; i++ )
  {
    val[X] = (float)i * rx  + xmin ;
    for( j = 0 ; j < size_y ; j++ )
    {
      val[Y] = (float)j * ry  + ymin ;
      for( k = 0 ; k < size_z ; k++ )
      {
        val[Z] = (float)k * rz  + zmin ;

      //  if( csg_root )
      //  {
      //    val[3] = csg_root->eval( val[X],val[Y],val[Z] ) ;
      //  }
        if( isofile  )
        {
          fread (buf, sizeof(float), 1, isofile);
          val[4] = * (float*) buf ;
        }

        w = fparser.Eval(val) - isoval ;
        mc.set_data( w, i,j,k ) ;
      }
    }
  }

  // Run MC
  mc.run_manifold_analyze() ;
  mc.clean_temps() ;
  return true ;
}



//_____________________________________________________________________________
// main function
int main(int argc, char* argv[])
//-----------------------------------------------------------------------------
	{

	char *nrrdfilename;
	char *isofilename;

	if(argc != 4)
	    {
	    std::cout << "Usage: " << argv[0] << "  Filename(nrrd format) isoval(float) isofile_name" << std::endl;
	    return 1;
	    }
	 else
	 {
		 nrrdfilename = argv[1];
		 isoval = atof(argv[2]);
		 isofilename    = argv[3];
	 }

	isoWriter writer;
	writer.read_nrrd(nrrdfilename);
	writer.Write(isofilename);

	char name[100];
	sprintf(name, "%s.iso",isofilename);
	isofile = fopen(name, "rb");

	reading_data();
	run();

	if(contk + contj == 0)
	{
		printf("It is not necessary to subdivide the grid.\n");
	}
	else
	{
		if(writer._data_type == 9)
		writer.IsoSubdivide_f(isofilename);
		if(writer._data_type == 2)
		writer.IsoSubdivide_u(isofilename);
		if(writer._data_type == 3)
		writer.IsoSubdivide_s(isofilename);
		printf("%d subdivisions. A new grid was generated.\n", contk+contj);
	}

return 0;
}



