/**
 * @file    MarchingCubes.cpp
 * @author  Thomas Lewiner <thomas.lewiner@polytechnique.org>
 * @author  Math Dept, PUC-Rio
 * @version 0.2
 * @date    12/08/2002
 *
 * @brief   MarchingCubes Algorithm
 */
//________________________________________________
#if !defined(WIN32) || defined(__CYGWIN__)
#pragma implementation
#endif // WIN32
#include <math.h>
#include <time.h>
#include <memory.h>
#include <stdlib.h>
#include <stddef.h>
#include <float.h>
#include "MarchingCubes.h"
#include "LookUpTable.h"
#include "defs.h"

 extern unsigned char k_f[200];
 extern float t_f[200];
 extern float eps;
 extern unsigned char contk;
 extern unsigned char contj;

unsigned char MCcase[32] = { 0 };

using namespace std;

// step size of the arrays of vertices and triangles
#define ALLOC_SIZE 65536

//_____________________________________________________________________________
// print cube for debug
void
MarchingCubes::print_cube()
{
  printf("\t%f %f %f %f %f %f %f %f\n", _cube[0], _cube[1], _cube[2], _cube[3],
      _cube[4], _cube[5], _cube[6], _cube[7]);
}
//_____________________________________________________________________________
// Constructor
MarchingCubes::MarchingCubes(const int size_x /*= -1*/,
    const int size_y /*= -1*/, const int size_z /*= -1*/) :
//-----------------------------------------------------------------------------
    _originalMC(false), _ext_data(false), _size_x(size_x), _size_y(size_y), _size_z(
        size_z), _data((real *) NULL), _x_verts((int *) NULL), _y_verts(
        (int *) NULL), _z_verts((int *) NULL), _nverts(0), _ntrigs(0), _Nverts(
        0), _Ntrigs(0), _vertices((Vertex *) NULL), _triangles((Triangle*) NULL)
{
}
//_____________________________________________________________________________
MarchingCubes::~MarchingCubes()
{
}
//_____________________________________________________________________________
// main algorithm
void
MarchingCubes::run_manifold_analyze(real iso)
//-----------------------------------------------------------------------------
{
  unsigned char size_nk = 0;
  unsigned char size_nj = 0;
  unsigned char k[300];
  float tk[300];
  unsigned char j[300];
  float tj[300];
  unsigned char c_result;
  unsigned char neighbor_result;
  float a, b, y;



  for (_k = 0; _k < _size_z - 1; _k++)
    for (_j = 0; _j < _size_y - 1; _j++)
      for (_i = 0; _i < _size_x - 1; _i++)
        {
          _lut_entry = 0;

          for (int p = 0; p < 8; ++p)
            {
              _cube[p] = get_data(_i + ((p ^ (p >> 1)) & 1),
                  _j + ((p >> 1) & 1), _k + ((p >> 2) & 1)) - iso;
              if (fabs(_cube[p]) < FLT_EPSILON)
                _cube[p] = FLT_EPSILON;
              if (_cube[p] > 0)
                _lut_entry += 1 << p;
            }
          c_result = process_cube_manifold_analyze();

          if (c_result == 1)
            {
              // neighbor[0]->(i-1, j, k)
              if (_i != 0)
                {
                  _lut_entry = 0;
                  for (int p = 0; p < 8; ++p)
                    {
                      _cube[p] = get_data((_i - 1) + ((p ^ (p >> 1)) & 1),
                          _j + ((p >> 1) & 1), _k + ((p >> 2) & 1)) - iso;
                      if (fabs(_cube[p]) < FLT_EPSILON)
                        _cube[p] = FLT_EPSILON;
                      if (_cube[p] > 0)
                        _lut_entry += 1 << p;
                    }
                  neighbor_result = 0;
                  neighbor_result = process_cube_manifold_analyze();

                  if ((neighbor_result == 1) && ((_cube[1] * _cube[6]) > 0.0)
                      && ((_cube[5] * _cube[2]) > 0.0))
                    {
                      // calculating the interpolant over the face
                      // f(x, y) = axy + bx + cy + d
                      a = _cube[1] - _cube[2] - _cube[5] + _cube[6];
                      b = _cube[2] - _cube[1];

                      // the y coordinates of the critical point
                      y = -b / a;

                      k[size_nk] = _k;
                      tk[size_nk] = y;
                      ++size_nk;
                    }
                }
              // neighbor[1]->(i+1, j, k)
              if (_i != _size_x - 1)
                {
                  _lut_entry = 0;
                  for (int p = 0; p < 8; ++p)
                    {
                      _cube[p] = get_data((_i + 1) + ((p ^ (p >> 1)) & 1),
                          _j + ((p >> 1) & 1), _k + ((p >> 2) & 1)) - iso;
                      if (fabs(_cube[p]) < FLT_EPSILON)
                        _cube[p] = FLT_EPSILON;
                      if (_cube[p] > 0)
                        _lut_entry += 1 << p;
                    }
                  neighbor_result = 0;
                  neighbor_result = process_cube_manifold_analyze();

                  if ((neighbor_result == 1) && ((_cube[0] * _cube[7]) > 0.0)
                      && ((_cube[4] * _cube[3]) > 0.0))
                    {
                      // calculating the interpolant over the face
                      // f(x, y) = axy + bx + cy + d
                      a = _cube[0] - _cube[3] - _cube[4] + _cube[7];
                      b = _cube[3] - _cube[0];

                      // the y coordinates of the critical point
                      y = -b / a;

                      k[size_nk] = _k;
                      tk[size_nk] = y;
                      ++size_nk;

                    }
                }
              // neighbor[2]->(i, j-1, k)
              if (_j != 0)
                {
                  _lut_entry = 0;
                  for (int p = 0; p < 8; ++p)
                    {
                      _cube[p] = get_data(_i + ((p ^ (p >> 1)) & 1),
                          (_j - 1) + ((p >> 1) & 1), _k + ((p >> 2) & 1)) - iso;
                      if (fabs(_cube[p]) < FLT_EPSILON)
                        _cube[p] = FLT_EPSILON;
                      if (_cube[p] > 0)
                        _lut_entry += 1 << p;
                    }
                  neighbor_result = 0;
                  neighbor_result = process_cube_manifold_analyze();

                  if ((neighbor_result == 1) && ((_cube[7] * _cube[2]) > 0.0)
                      && ((_cube[6] * _cube[3]) > 0.0))
                    {
                      // calculating the interpolant over the face
                      // f(x, y) = axy + bx + cy + d
                      a = _cube[3] - _cube[2] - _cube[7] + _cube[6];
                      b = _cube[2] - _cube[3];

                      // the y coordinates of the critical point
                      y = -b / a;

                      k[size_nk] = _k;
                      tk[size_nk] = y;
                      ++size_nk;

                    }
                }
              // neighbor[3]->(i, j+1, k)
              if (_j != _size_y - 1)
                {
                  _lut_entry = 0;
                  for (int p = 0; p < 8; ++p)
                    {
                      _cube[p] = get_data(_i + ((p ^ (p >> 1)) & 1),
                          (_j + 1) + ((p >> 1) & 1), _k + ((p >> 2) & 1)) - iso;
                      if (fabs(_cube[p]) < FLT_EPSILON)
                        _cube[p] = FLT_EPSILON;
                      if (_cube[p] > 0)
                        _lut_entry += 1 << p;
                    }
                  neighbor_result = 0;
                  neighbor_result = process_cube_manifold_analyze();

                  if ((neighbor_result == 1) && ((_cube[0] * _cube[5]) > 0.0)
                      && ((_cube[4] * _cube[1]) > 0.0))
                    {
                      // calculating the interpolant over the face
                      // f(x, y) = axy + bx + cy + d
                      a = _cube[0] - _cube[1] - _cube[4] + _cube[5];
                      b = _cube[1] - _cube[0];

                      // the y coordinates of the critical point
                      y = -b / a;

                      k[size_nk] = _k;
                      tk[size_nk] = y;
                      ++size_nk;

                    }
                }
              // neighbor[4]->(i, j, k -1)
              if (_k != 0)
                {
                  _lut_entry = 0;
                  for (int p = 0; p < 8; ++p)
                    {
                      _cube[p] = get_data(_i + ((p ^ (p >> 1)) & 1),
                          _j + ((p >> 1) & 1), (_k - 1) + ((p >> 2) & 1)) - iso;
                      if (fabs(_cube[p]) < FLT_EPSILON)
                        _cube[p] = FLT_EPSILON;
                      if (_cube[p] > 0)
                        _lut_entry += 1 << p;
                    }
                  neighbor_result = 0;
                  neighbor_result = process_cube_manifold_analyze();

                  if ((neighbor_result == 1) && ((_cube[5] * _cube[7]) > 0.0)
                      && ((_cube[4] * _cube[6]) > 0.0))
                    {
                      // calculating the interpolant over the face
                      // f(x, y) = axy + bx + cy + d
                      a = _cube[4] - _cube[5] - _cube[7] + _cube[6];
                      b = _cube[5] - _cube[4];

                      // the y coordinates of the critical point
                      y = -b / a;

                      j[size_nj] = _j;
                      tj[size_nj] = y;
                      ++size_nj;

                    }
                }
              // neighbor[5]->(i, j, k +1)
              if (_k != _size_z - 1)
                {
                  _lut_entry = 0;
                  for (int p = 0; p < 8; ++p)
                    {
                      _cube[p] = get_data(_i + ((p ^ (p >> 1)) & 1),
                          _j + ((p >> 1) & 1), (_k + 1) + ((p >> 2) & 1)) - iso;
                      if (fabs(_cube[p]) < FLT_EPSILON)
                        _cube[p] = FLT_EPSILON;
                      if (_cube[p] > 0)
                        _lut_entry += 1 << p;
                    }
                  neighbor_result = 0;
                  neighbor_result = process_cube_manifold_analyze();

                  if ((neighbor_result == 1) && ((_cube[0] * _cube[2]) > 0.0)
                      && ((_cube[1] * _cube[3]) > 0.0))
                    {
                      // calculating the interpolant over the face
                      // f(x, y) = axy + bx + cy + d
                      a = _cube[0] - _cube[3] - _cube[1] + _cube[2];
                      b = _cube[1] - _cube[0];

                      // the y coordinates of the critical point
                      y = -b / a;

                      j[size_nj] = _j;
                      tj[size_nj] = y;
                      ++size_nj;

                    }
                }
            }
        }




  for (int i = 0; i < size_nk; ++i)
    {
      if ((fabs(tk[i]) > eps) && (fabs(1 - tk[i]) > eps) && (tk[i] > 0))
        {
          int k_ = k[i];

          k_f[contk] = k[i];
          t_f[contk] = tk[i];
          while (k[i] == k_)
            {
              ++i;
            }
          --i;
          ++contk;
        }
    }

  //sorting arrays j[i] and tj[i]
  for (int m = 1; m < size_nj; m++)
    {
      for (int n = 0; n < size_nj - 1; n++)
        {
          if (j[n] >= j[n + 1])
            {
              int tempj = j[n];
              j[n] = j[n + 1];
              j[n + 1] = tempj;

              float tempt = tj[n];
              tj[n] = tj[n+ 1];
              tj[n+1] = tempt;
            }
        }
    }

  for (int i = 0; i < size_nj; ++i)
    {
      if ((fabs(tj[i]) > eps) && (fabs(1 - tj[i]) > eps) && (tj[i] > 0))
        {
          int j_ = j[i];

          k_f[contk + contj] = j[i];
          t_f[contk + contj] = tj[i];
          while (j[i] == j_)
            {
              ++i;
            }
          --i;
          ++contj;
        }
    }
}
//-----------------------------------------------------------------------------
// init temporary structures (must set sizes before call)
void
MarchingCubes::init_temps()

{
  if (!_ext_data)
    _data = new real[_size_x * _size_y * _size_z];
  _x_verts = new int[_size_x * _size_y * _size_z];
  _y_verts = new int[_size_x * _size_y * _size_z];
  _z_verts = new int[_size_x * _size_y * _size_z];

  memset(_x_verts, -1, _size_x * _size_y * _size_z * sizeof(int));
  memset(_y_verts, -1, _size_x * _size_y * _size_z * sizeof(int));
  memset(_z_verts, -1, _size_x * _size_y * _size_z * sizeof(int));
}
//_____________________________________________________________________________
// clean temporary structures
void
MarchingCubes::clean_temps()
//-----------------------------------------------------------------------------
{
  if (!_ext_data)
    delete[] _data;
  delete[] _x_verts;
  delete[] _y_verts;
  delete[] _z_verts;

  if (!_ext_data)
    _data = (real*) NULL;
  _x_verts = (int*) NULL;
  _y_verts = (int*) NULL;
  _z_verts = (int*) NULL;
}
//_____________________________________________________________________________
// Test a face
// if face>0 return true if the face contains a part of the surface
bool
MarchingCubes::test_face(schar face)
//-----------------------------------------------------------------------------
{
  real A, B, C, D;

  switch (face)
    {
  case -1:
  case 1:
    A = _cube[0];
    B = _cube[4];
    C = _cube[5];
    D = _cube[1];
    break;
  case -2:
  case 2:
    A = _cube[1];
    B = _cube[5];
    C = _cube[6];
    D = _cube[2];
    break;
  case -3:
  case 3:
    A = _cube[2];
    B = _cube[6];
    C = _cube[7];
    D = _cube[3];
    break;
  case -4:
  case 4:
    A = _cube[3];
    B = _cube[7];
    C = _cube[4];
    D = _cube[0];
    break;
  case -5:
  case 5:
    A = _cube[0];
    B = _cube[3];
    C = _cube[2];
    D = _cube[1];
    break;
  case -6:
  case 6:
    A = _cube[4];
    B = _cube[7];
    C = _cube[6];
    D = _cube[5];
    break;

  default:
    printf("Invalid face code %d\n", face);
    print_cube();
    A = B = C = D = 0;
    break;
    };

  if (fabs(A * C - B * D) < FLT_EPSILON)
    return face >= 0;

  return face * A * (A * C - B * D) >= 0; //face and A invert signs
}
//________________________________________________________________________________________________________
//________________________________________________________________________________________________________

// Once I have the ambiguity face, I have the plane test orientation (parallel to axis x, y or z).
// But I still need to figure out witch vertices are involved in interior ambiguity.
//
int
MarchingCubes::interior_ambiguity(int amb_face, int s)
{
  int edge;

  switch (amb_face)
    {
  case 1:
  case 3:
    if (((_cube[1] * s) > 0) && ((_cube[7] * s) > 0))
      edge = 4;
    if (((_cube[0] * s) > 0) && ((_cube[6] * s) > 0))
      edge = 5;
    if (((_cube[3] * s) > 0) && ((_cube[5] * s) > 0))
      edge = 6;
    if (((_cube[2] * s) > 0) && ((_cube[4] * s) > 0))
      edge = 7;

    break;

  case 2:
  case 4:
    if (((_cube[1] * s) > 0) && ((_cube[7] * s) > 0))
      edge = 0;
    if (((_cube[2] * s) > 0) && ((_cube[4] * s) > 0))
      edge = 1;
    if (((_cube[3] * s) > 0) && ((_cube[5] * s) > 0))
      edge = 2;
    if (((_cube[0] * s) > 0) && ((_cube[6] * s) > 0))
      edge = 3;
    break;

  case 5:
  case 6:
  case 0:
    if (((_cube[0] * s) > 0) && ((_cube[6] * s) > 0))
      edge = 8;
    if (((_cube[1] * s) > 0) && ((_cube[7] * s) > 0))
      edge = 9;
    if (((_cube[2] * s) > 0) && ((_cube[4] * s) > 0))
      edge = 10;
    if (((_cube[3] * s) > 0) && ((_cube[5] * s) > 0))
      edge = 11;

    break;
    }

  return edge;
}
//-----------------------------------------------------------------------------

int
MarchingCubes::interior_ambiguity_verification(int edge)
{
  double t, At = 0, Bt = 0, Ct = 0, Dt = 0, a = 0, b = 0;
  double verify;

  switch (edge)
    {

  case 0:
    a = (_cube[0] - _cube[1]) * (_cube[7] - _cube[6])
        - (_cube[4] - _cube[5]) * (_cube[3] - _cube[2]);
    b = _cube[6] * (_cube[0] - _cube[1]) + _cube[1] * (_cube[7] - _cube[6])
        - _cube[2] * (_cube[4] - _cube[5]) - _cube[5] * (_cube[3] - _cube[2]);

    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[1] + (_cube[0] - _cube[1]) * t;
    Bt = _cube[5] + (_cube[4] - _cube[5]) * t;
    Ct = _cube[6] + (_cube[7] - _cube[6]) * t;
    Dt = _cube[2] + (_cube[3] - _cube[2]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;

    break;

  case 1:
    a = (_cube[3] - _cube[2]) * (_cube[4] - _cube[5])
        - (_cube[0] - _cube[1]) * (_cube[7] - _cube[6]);
    b = _cube[5] * (_cube[3] - _cube[2]) + _cube[2] * (_cube[4] - _cube[5])
        - _cube[6] * (_cube[0] - _cube[1]) - _cube[1] * (_cube[7] - _cube[6]);

    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[2] + (_cube[3] - _cube[2]) * t;
    Bt = _cube[1] + (_cube[0] - _cube[1]) * t;
    Ct = _cube[5] + (_cube[4] - _cube[5]) * t;
    Dt = _cube[6] + (_cube[7] - _cube[6]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 2:
    a = (_cube[2] - _cube[3]) * (_cube[5] - _cube[4])
        - (_cube[6] - _cube[7]) * (_cube[1] - _cube[0]);
    b = _cube[4] * (_cube[2] - _cube[3]) + _cube[3] * (_cube[5] - _cube[4])
        - _cube[0] * (_cube[6] - _cube[7]) - _cube[7] * (_cube[1] - _cube[0]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[3] + (_cube[2] - _cube[3]) * t;
    Bt = _cube[7] + (_cube[6] - _cube[7]) * t;
    Ct = _cube[4] + (_cube[5] - _cube[4]) * t;
    Dt = _cube[0] + (_cube[1] - _cube[0]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 3:
    a = (_cube[1] - _cube[0]) * (_cube[6] - _cube[7])
        - (_cube[2] - _cube[3]) * (_cube[5] - _cube[4]);
    b = _cube[7] * (_cube[1] - _cube[0]) + _cube[0] * (_cube[6] - _cube[7])
        - _cube[4] * (_cube[2] - _cube[3]) - _cube[3] * (_cube[5] - _cube[4]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[0] + (_cube[1] - _cube[0]) * t;
    Bt = _cube[3] + (_cube[2] - _cube[3]) * t;
    Ct = _cube[7] + (_cube[6] - _cube[7]) * t;
    Dt = _cube[4] + (_cube[5] - _cube[4]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 4:

    a = (_cube[2] - _cube[1]) * (_cube[7] - _cube[4])
        - (_cube[3] - _cube[0]) * (_cube[6] - _cube[5]);
    b = _cube[4] * (_cube[2] - _cube[1]) + _cube[1] * (_cube[7] - _cube[4])
        - _cube[5] * (_cube[3] - _cube[0]) - _cube[0] * (_cube[6] - _cube[5]);

    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[1] + (_cube[2] - _cube[1]) * t;
    Bt = _cube[0] + (_cube[3] - _cube[0]) * t;
    Ct = _cube[4] + (_cube[7] - _cube[4]) * t;
    Dt = _cube[5] + (_cube[6] - _cube[5]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 5:

    a = (_cube[3] - _cube[0]) * (_cube[6] - _cube[5])
        - (_cube[2] - _cube[1]) * (_cube[7] - _cube[4]);
    b = _cube[5] * (_cube[3] - _cube[0]) + _cube[0] * (_cube[6] - _cube[5])
        - _cube[4] * (_cube[2] - _cube[1]) - _cube[1] * (_cube[7] - _cube[4]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[0] + (_cube[3] - _cube[0]) * t;
    Bt = _cube[1] + (_cube[2] - _cube[1]) * t;
    Ct = _cube[5] + (_cube[6] - _cube[5]) * t;
    Dt = _cube[4] + (_cube[7] - _cube[4]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 6:
    a = (_cube[0] - _cube[3]) * (_cube[5] - _cube[6])
        - (_cube[4] - _cube[7]) * (_cube[1] - _cube[2]);
    b = _cube[6] * (_cube[0] - _cube[3]) + _cube[3] * (_cube[5] - _cube[6])
        - _cube[2] * (_cube[4] - _cube[7]) - _cube[7] * (_cube[1] - _cube[2]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[3] + (_cube[0] - _cube[3]) * t;
    Bt = _cube[7] + (_cube[4] - _cube[7]) * t;
    Ct = _cube[6] + (_cube[5] - _cube[6]) * t;
    Dt = _cube[2] + (_cube[1] - _cube[2]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 7:
    a = (_cube[1] - _cube[2]) * (_cube[4] - _cube[7])
        - (_cube[0] - _cube[3]) * (_cube[5] - _cube[6]);
    b = _cube[7] * (_cube[1] - _cube[2]) + _cube[2] * (_cube[4] - _cube[7])
        - _cube[6] * (_cube[0] - _cube[3]) - _cube[3] * (_cube[5] - _cube[6]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[2] + (_cube[1] - _cube[2]) * t;
    Bt = _cube[3] + (_cube[0] - _cube[3]) * t;
    Ct = _cube[7] + (_cube[4] - _cube[7]) * t;
    Dt = _cube[6] + (_cube[5] - _cube[6]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 8:
    a = (_cube[4] - _cube[0]) * (_cube[6] - _cube[2])
        - (_cube[7] - _cube[3]) * (_cube[5] - _cube[1]);
    b = _cube[2] * (_cube[4] - _cube[0]) + _cube[0] * (_cube[6] - _cube[2])
        - _cube[1] * (_cube[7] - _cube[3]) - _cube[3] * (_cube[5] - _cube[1]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[0] + (_cube[4] - _cube[0]) * t;
    Bt = _cube[3] + (_cube[7] - _cube[3]) * t;
    Ct = _cube[2] + (_cube[6] - _cube[2]) * t;
    Dt = _cube[1] + (_cube[5] - _cube[1]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 9:
    a = (_cube[5] - _cube[1]) * (_cube[7] - _cube[3])
        - (_cube[4] - _cube[0]) * (_cube[6] - _cube[2]);
    b = _cube[3] * (_cube[5] - _cube[1]) + _cube[1] * (_cube[7] - _cube[3])
        - _cube[2] * (_cube[4] - _cube[0]) - _cube[0] * (_cube[6] - _cube[2]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[1] + (_cube[5] - _cube[1]) * t;
    Bt = _cube[0] + (_cube[4] - _cube[0]) * t;
    Ct = _cube[3] + (_cube[7] - _cube[3]) * t;
    Dt = _cube[2] + (_cube[6] - _cube[2]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 10:
    a = (_cube[6] - _cube[2]) * (_cube[4] - _cube[0])
        - (_cube[5] - _cube[1]) * (_cube[7] - _cube[3]);
    b = _cube[0] * (_cube[6] - _cube[2]) + _cube[2] * (_cube[4] - _cube[0])
        - _cube[3] * (_cube[5] - _cube[1]) - _cube[1] * (_cube[7] - _cube[3]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[2] + (_cube[6] - _cube[2]) * t;
    Bt = _cube[1] + (_cube[5] - _cube[1]) * t;
    Ct = _cube[0] + (_cube[4] - _cube[0]) * t;
    Dt = _cube[3] + (_cube[7] - _cube[3]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;

  case 11:
    a = (_cube[7] - _cube[3]) * (_cube[5] - _cube[1])
        - (_cube[6] - _cube[2]) * (_cube[4] - _cube[0]);
    b = _cube[1] * (_cube[7] - _cube[3]) + _cube[3] * (_cube[5] - _cube[1])
        - _cube[0] * (_cube[6] - _cube[2]) - _cube[2] * (_cube[4] - _cube[0]);
    if (a > 0)
      return 1;

    t = -b / (2 * a);
    if (t < 0 || t > 1)
      return 1;

    At = _cube[3] + (_cube[7] - _cube[3]) * t;
    Bt = _cube[2] + (_cube[6] - _cube[2]) * t;
    Ct = _cube[1] + (_cube[5] - _cube[1]) * t;
    Dt = _cube[0] + (_cube[4] - _cube[0]) * t;

    verify = At * Ct - Bt * Dt;

    if (verify > 0)
      return 0;
    if (verify < 0)
      return 1;
    break;
    }

  return 0;
}

bool
MarchingCubes::modified_test_interior(schar s)
//-----------------------------------------------------------------------------
{

  char edge = -1;
  int amb_face;

  int inter_amb = 0;

  switch (_case)
    {
  case 4:

    amb_face = 1;
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    amb_face = 2;
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    amb_face = 5;
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    if (inter_amb == 0)
      return false;
    else
      return true;
    break;

  case 6:

    amb_face = abs(test6[_config][0]);

    edge = interior_ambiguity(amb_face, s);
    inter_amb = interior_ambiguity_verification(edge);

    if (inter_amb == 0)
      return false;
    else
      return true;

    break;

  case 7:
    s = s * -1;

    amb_face = 1;
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    amb_face = 2;
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    amb_face = 5;
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    if (inter_amb == 0)
      return false;
    else
      return true;
    break;

  case 10:

    amb_face = abs(test10[_config][0]);

    edge = interior_ambiguity(amb_face, s);
    inter_amb = interior_ambiguity_verification(edge);

    if (inter_amb == 0)
      return false;
    else
      return true;
    break;

  case 12:
    amb_face = abs(test12[_config][0]);
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    amb_face = abs(test12[_config][1]);
    edge = interior_ambiguity(amb_face, s);
    inter_amb += interior_ambiguity_verification(edge);

    if (inter_amb == 0)
      return false;
    else
      return true;
    break;
    }

  return true;
}
//_____________________________________________________________________________
// NEW INTERIOR TEST FOR CASE 13
// Return true if the interior is empty(two faces)

// control the tunnel orientation triangulation
int tunelorientation = 0;

bool
MarchingCubes::new_interior_test(int isovalue)
{

  double critival_point_value1, critival_point_value2;

  double a = -_cube[0] + _cube[1] + _cube[3] - _cube[2] + _cube[4] - _cube[5]
      - _cube[7] + _cube[6], b = _cube[0] - _cube[1] - _cube[3] + _cube[2], c =
      _cube[0] - _cube[1] - _cube[4] + _cube[5], d = _cube[0] - _cube[3]
      - _cube[4] + _cube[7], e = -_cube[0] + _cube[1], f = -_cube[0] + _cube[3],
      g = -_cube[0] + _cube[4], h = _cube[0];

  double x1, y1, z1, x2, y2, z2;
  int numbercritivalpoints = 0;

  double dx = b * c - a * e, dy = b * d - a * f, dz = c * d - a * g;

  if (dx != 0.0f && dy != 0.0f && dz != 0.0f)
    {
      if (dx * dy * dz < 0)
        return true;

      double disc = sqrt(dx * dy * dz);

      x1 = (-d * dx - disc) / (a * dx);
      y1 = (-c * dy - disc) / (a * dy);
      z1 = (-b * dz - disc) / (a * dz);

      if ((x1 > 0) && (x1 < 1) && (y1 > 0) && (y1 < 1) && (z1 > 0) && (z1 < 1))
        {
          numbercritivalpoints++;

          critival_point_value1 = a * x1 * y1 * z1 + b * x1 * y1 + c * x1 * z1
              + d * y1 * z1 + e * x1 + f * y1 + g * z1 + h - isovalue;
        }

      x2 = (-d * dx + disc) / (a * dx);
      y2 = (-c * dy + disc) / (a * dy);
      z2 = (-b * dz + disc) / (a * dz);

      if ((x2 > 0) && (x2 < 1) && (y2 > 0) && (y2 < 1) && (z2 > 0) && (z2 < 1))
        {
          numbercritivalpoints++;

          critival_point_value2 = a * x2 * y2 * z2 + b * x2 * y2 + c * x2 * z2
              + d * y2 * z2 + e * x2 + f * y2 + g * z2 + h - isovalue;

        }

      if (numbercritivalpoints < 2)
        return true;
      else
        {
          if ((critival_point_value1 * critival_point_value2 > 0))
            {
              if (critival_point_value1 > 0)
                tunelorientation = 1;
              else
                tunelorientation = -1;
            }

          return critival_point_value1 * critival_point_value2 < 0;
        }

    }
  else
    return true;
}
//_____________________________________________________________________________

//_____________________________________________________________________________
// Process a unit cube
int
MarchingCubes::process_cube_manifold_analyze()
//-----------------------------------------------------------------------------
{

  _case = cases[_lut_entry][0];
  _config = cases[_lut_entry][1];
  _subconfig = 0;

  if ((_case == 7) || (_case == 10) || (_case == 12) || (_case == 13))
    {
      switch (_case)
        {
      case 7:
        if (test_face(test7[_config][0]))
          _subconfig += 1;
        if (test_face(test7[_config][1]))
          _subconfig += 2;
        if (test_face(test7[_config][2]))
          _subconfig += 4;

        if (_subconfig == 7)
          {
            if (modified_test_interior(test7[_config][3]))
              return 0;
            else
              return 1;
          }
        else
          return 0;

        break;

      case 10:
        if (test_face(test10[_config][0]))
          {
            if (test_face(test10[_config][1]))
              {
                if (modified_test_interior(-test10[_config][2]))
                  return 0;
                else
                  return 1;

              }
            else
              {
                return 0;
              }
          }
        else
          {
            if (test_face(test10[_config][1]))
              {
                return 0;
              }
            else
              {
                if (modified_test_interior(test10[_config][2]))
                  return 0;
                else
                  return 1;
              }
          }
        break;

      case 12:
        if (test_face(test12[_config][0]))
          {
            if (test_face(test12[_config][1]))
              {
                if (modified_test_interior(-test12[_config][2]))
                  return 0;
                else
                  return 1;
              }
            else
              {
                return 0;
              }
          }
        else
          {
            if (test_face(test12[_config][1]))
              {
                return 0;
              }
            else
              {
                if (modified_test_interior(test12[_config][2]))
                  return 0;
                else
                  return 1;
              }
          }
        break;
      case 13:
        if (test_face(test13[_config][0]))
          _subconfig += 1;
        if (test_face(test13[_config][1]))
          _subconfig += 2;
        if (test_face(test13[_config][2]))
          _subconfig += 4;
        if (test_face(test13[_config][3]))
          _subconfig += 8;
        if (test_face(test13[_config][4]))
          _subconfig += 16;
        if (test_face(test13[_config][5]))
          _subconfig += 32;

        if ((subconfig13[_subconfig] > 22) && (subconfig13[_subconfig] < 27))
          {
            switch (subconfig13[_subconfig])
              {
            case 23:/* 13.5 */
              _subconfig = 0;
              if (_config == 0)
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              else
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              break;

            case 24:/* 13.5 */
              _subconfig = 1;
              if (_config == 0)
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              else
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              break;

            case 25:/* 13.5 */
              _subconfig = 2;
              if (_config == 0)
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              else
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              break;

            case 26: /* 13.5 */
              _subconfig = 3;
              if (_config == 0)
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              else
                {
                  if (new_interior_test(0))
                    return 0;
                  else
                    return 1;

                }
              break;
              }

          }
        else
          return 0;
        break;
        }

    }
  else
    return 0;

}

int
MarchingCubes::process_cube_case_analyze()
//-----------------------------------------------------------------------------
{

  _case = cases[_lut_entry][0];
  _config = cases[_lut_entry][1];
  _subconfig = 0;

  switch (_case)
    {
  case 0:
    ++MCcase[0];
    break;

  case 1:
    ++MCcase[1];
    break;

  case 2:
    ++MCcase[2];
    break;

  case 3:
    if (test_face(test3[_config]))
      ++MCcase[4]; // 3.2
    else
      ++MCcase[3]; // 3.1
    break;

  case 4:
    if (modified_test_interior(test4[_config]))
      ++MCcase[5]; // 4.1.1
    else
      ++MCcase[6]; // 4.1.2
    break;

  case 5:
    ++MCcase[7];
    break;

  case 6:
    if (test_face(test6[_config][0]))
      ++MCcase[10];

    else
      {
        if (modified_test_interior(test6[_config][1]))
          ++MCcase[8];

        else
          ++MCcase[9];

      }
    break;
  case 7:
    if (test_face(test7[_config][0]))
      _subconfig += 1;
    if (test_face(test7[_config][1]))
      _subconfig += 2;
    if (test_face(test7[_config][2]))
      _subconfig += 4;

    switch (_subconfig)
      {
    case 0:
      ++MCcase[11];
      break;
    case 1:
      ++MCcase[12];
      break;
    case 2:
      ++MCcase[12];
      break;
    case 3:
      ++MCcase[13];
      break;
    case 4:
      ++MCcase[12];
      break;
    case 5:
      ++MCcase[13];
      break;
    case 6:
      ++MCcase[12];
      break;
    case 7:
      if (modified_test_interior(test7[_config][3]))
        ++MCcase[14];
      else
        ++MCcase[15];
      break;
      }
    break;

  case 8:
    ++MCcase[16];
    break;
  case 9:
    ++MCcase[17];
    break;

  case 10:
    if (test_face(test10[_config][0]))
      {
        if (test_face(test10[_config][1]))
          {
            if (modified_test_interior(-test10[_config][2]))
              ++MCcase[18];
            else
              ++MCcase[19];
          }
        else
          ++MCcase[20];
      }
    else
      {
        if (test_face(test10[_config][1]))
          ++MCcase[20];

        else
          {
            if (modified_test_interior(test10[_config][2]))
              ++MCcase[18];
            else
              ++MCcase[19];
          }
      }
    break;

  case 11:
    ++MCcase[21];
    break;

  case 12:
    if (test_face(test12[_config][0]))
      {
        if (test_face(test12[_config][1]))
          {
            if (modified_test_interior(-test12[_config][2]))
              ++MCcase[22];
            else
              ++MCcase[23];
          }
        else
          ++MCcase[24];
      }
    else
      {
        if (test_face(test12[_config][1]))
          ++MCcase[24];
        else
          {
            if (modified_test_interior(test12[_config][2]))
              ++MCcase[22];
            else
              ++MCcase[23];
          }
      }
    break;
  case 13:
    if (test_face(test13[_config][0]))
      _subconfig += 1;
    if (test_face(test13[_config][1]))
      _subconfig += 2;
    if (test_face(test13[_config][2]))
      _subconfig += 4;
    if (test_face(test13[_config][3]))
      _subconfig += 8;
    if (test_face(test13[_config][4]))
      _subconfig += 16;
    if (test_face(test13[_config][5]))
      _subconfig += 32;

    switch (subconfig13[_subconfig])
      {
    case 0:/* 13.1 */
      ++MCcase[25];
      break;

    case 1:/* 13.2 */
      ++MCcase[26];
      break;
    case 2:/* 13.2 */
      ++MCcase[26];
      break;
    case 3:/* 13.2 */
      ++MCcase[26];
      break;
    case 4:/* 13.2 */
      ++MCcase[26];
      break;
    case 5:/* 13.2 */
      ++MCcase[26];
      break;
    case 6:/* 13.2 */
      ++MCcase[26];
      break;

    case 7:/* 13.3 */
      ++MCcase[27];
      break;

    case 8:/* 13.3 */
      ++MCcase[27];
      break;

    case 9:/* 13.3 */
      ++MCcase[27];
      break;

    case 10:/* 13.3 */
      ++MCcase[27];
      break;

    case 11:/* 13.3 */
      ++MCcase[27];
      break;

    case 12:/* 13.3 */
      ++MCcase[27];
      break;

    case 13:/* 13.3 */
      ++MCcase[27];
      break;

    case 14:/* 13.3 */
      ++MCcase[27];
      break;

    case 15:/* 13.3 */
      ++MCcase[27];
      break;

    case 16:/* 13.3 */
      ++MCcase[27];
      break;

    case 17:/* 13.3 */
      ++MCcase[27];
      break;

    case 18:/* 13.3 */
      ++MCcase[27];
      break;

    case 19:/* 13.4 */
      ++MCcase[28];
      break;
      ++MCcase[28];
      break;
    case 21:/* 13.4 */
      ++MCcase[28];
      break;
    case 22:/* 13.4 */
      ++MCcase[28];
      break;

    case 23:/* 13.5 */
      _subconfig = 0;
      if (_config == 0)
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      else
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      break;

    case 24:/* 13.5 */
      _subconfig = 1;
      if (_config == 0)
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      else
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      break;

    case 25:/* 13.5 */
      _subconfig = 2;
      if (_config == 0)
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      else
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      break;

    case 26: /* 13.5 */
      _subconfig = 3;
      if (_config == 0)
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      else
        {
          if (new_interior_test(0))
            ++MCcase[29];
          else
            ++MCcase[30];
        }
      break;

    case 27:/* 13.3 */
      ++MCcase[27];
      break;

    case 28:/* 13.3 */
      ++MCcase[27];
      break;

    case 29:/* 13.3 */
      ++MCcase[27];
      break;

    case 30:/* 13.3 */
      ++MCcase[27];
      break;

    case 31:/* 13.3 */
      ++MCcase[27];
      break;

    case 32:/* 13.3 */
      ++MCcase[27];
      break;

    case 33:/* 13.3 */
      ++MCcase[27];
      break;

    case 34:/* 13.3 */
      ++MCcase[27];
      break;

    case 35:/* 13.3 */
      ++MCcase[27];
      break;

    case 36:/* 13.3 */
      ++MCcase[27];
      break;

    case 37:/* 13.3 */
      ++MCcase[27];
      break;

    case 38:/* 13.3 */
      ++MCcase[27];
      break;

    case 39:/* 13.2 */
      ++MCcase[26];
      break;
    case 40:/* 13.2 */
      ++MCcase[26];
      break;

    case 41:/* 13.2 */
      ++MCcase[26];
      break;

    case 42:/* 13.2 */
      ++MCcase[26];
      break;

    case 43:/* 13.2 */
      ++MCcase[26];
      break;

    case 44:/* 13.2 */
      ++MCcase[26];
      break;

    case 45:/* 13.1 */
      ++MCcase[25];
      break;

    default:
      printf("Marching Cubes: Impossible case 13?\n");
      break;

      }
    break;

  case 14:
    ++MCcase[31];
    return 0;
    break;

    }

  return 0;

}

