#ifndef ISOWRITER_HPP_
#define ISOWRITER_HPP_

#include <fstream>
#include <string>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include "teem/nrrd.h"



 extern unsigned char k_f[200];
 extern float t_f[200];
 extern float eps;
 extern unsigned char contk;
 extern unsigned char contj;

using namespace std;

class isoWriter
{

public:
	// array with the .raw data
	float *_data_f;
	short *_data_s;
	unsigned char *_data_u;

	int _data_type;
	// size of the data array
	int _n_data;

	// grid dimensions
	int _size_x;
	int _size_y;
	int _size_z;

	float _sx;
	float _sy;
	float _sz;

public:

	void read_nrrd(char *filename);
	int Write(const std::string fileName);
	int IsoSubdivide_f(const std::string fileName);
	int IsoSubdivide_u(const std::string fileName);
	int IsoSubdivide_s(const std::string fileName);


	static char* changeEndianness(char* byte, unsigned size)
	{
		for (int i = 0; i < (int) (size * 0.5); ++i)
		{
			char c;
			c = byte[i];
			byte[i] = byte[size - 1 - i];
			byte[size - 1 - i] = c;
		}

		return byte;
	}
};

void isoWriter::read_nrrd(char *filename)
{
	char *err;

	/* create a nrrd; at this point this is just an empty container */
	Nrrd *nin = nrrdNew();

	/* read in the nrrd from file */
	if (nrrdLoad(nin, filename, NULL))
	{
		err = biffGetDone(NRRD);
		fprintf(stderr, "read_nrrd: trouble reading \"%s\":\n%s", filename,
				err);
		free(err);
		return;
	}

	/* say something about the array */
	printf("read_nhdr: \"%s\" is a %d-dimensional nrrd of type %d (%s)\n",
			filename, nin->dim, nin->type, airEnumStr(nrrdType, nin->type));
	printf(
			"read_nhdr: the array contains %d elements, each %d bytes in size\n",
			(int) nrrdElementNumber(nin), (int) nrrdElementSize(nin));

	_size_x = nin->axis[0].size;
	_size_y = nin->axis[1].size;
	_size_z = nin->axis[2].size;

	_sx = nin->axis[0].spacing;
	_sy = nin->axis[1].spacing;
	_sz = nin->axis[2].spacing;

	_n_data = (int) nrrdElementNumber(nin);

	_data_type = nin->type;

	if (_data_type == 9)
	{
		_data_f = new float[_n_data];
		memcpy(_data_f, nin->data, _n_data * sizeof(float));
	}
	if (_data_type == 2)
	{
		_data_u = new unsigned char[_n_data];
		memcpy(_data_u, nin->data, _n_data * sizeof(unsigned char));
	}
	if (_data_type == 3)
	{
		_data_s = new short[_n_data];
		memcpy(_data_s, nin->data, _n_data * sizeof(short));
	}

	nrrdNuke(nin);

	return;
}
//==========================================================================================================
int isoWriter::Write( const std::string fileName)
{
	std::string isoFileName = fileName + ".iso";
	char* byte;

	std::ofstream fileISO(isoFileName.c_str(),
			std::ios::out | std::ios::binary);

	if (!fileISO.is_open())
	{
		std::cout << std::endl;
		std::cout << "\tCouldn't create specified file '" << isoFileName;
		std::cout << "'." << std::endl;
		return 1;
	}

	float mnx = 0.0, mny = 0.0, mnz = 0.0, mxx = _size_x * _sx, mxy = _size_y * _sy,
			mxz = _size_z * _sz;

	byte = reinterpret_cast<char*>(&_size_x);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&_size_y);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&_size_z);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&(mnx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mny));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxy));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mnz));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxz));
	fileISO.write(byte, sizeof(float));

	int i, j, k;
	for (i = 0; i < _size_x; ++i)
	{
		for (j = 0; j < _size_y; ++j)
			for (k = 0; k < _size_z; ++k)
			{

				if (_data_type == 9)
				{
					float value = _data_f[i + j * _size_x + k * _size_x * _size_y];
					byte = reinterpret_cast<char*>(&value);
				}

				if (_data_type == 2)
				{
					float value = _data_u[i + j * _size_x + k * _size_x * _size_y];
					byte = reinterpret_cast<char*>(&value);
				}

				if (_data_type == 3)
				{
					float value = _data_s[i + j * _size_x + k * _size_x * _size_y];
					byte = reinterpret_cast<char*>(&value);
				}

				fileISO.write(byte, sizeof(float));

			}

	}

	return 0;
}

//======================================================================================
int isoWriter::IsoSubdivide_f(const std::string fileName)
{

	float *data = new float [_n_data];
	data = _data_f;

	std::string isoFileName = fileName + ".iso";
	char* byte;

	std::ofstream fileISO(isoFileName.c_str(),
			std::ios::out | std::ios::binary);

	if (!fileISO.is_open())
	{
		std::cout << std::endl;
		std::cout << "\tCouldn't create specified file '" << isoFileName;
		std::cout << "'." << std::endl;
		return 1;
	}

    int increase_k = contk;
    int increase_j = contj;

	unsigned nz_ = _size_z + increase_k;
	unsigned ny_ = _size_y + increase_j;

	float mnx = 0.0, mny = 0.0, mnz = 0.0, mxx = _size_x * _sx, mxy = _size_y * _sy,
			mxz = _size_z * _sz;

	byte = reinterpret_cast<char*>(&_size_x);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&ny_);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&nz_);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&(mnx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mny));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxy));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mnz));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxz));
	fileISO.write(byte, sizeof(float));

	int verific_k = 0;
	int verific_j = 0;
	double a, b;
	float value;
	int i, j, k;

	for (i = 0; i < _size_x; ++i)
		for (j = 0; j < _size_y; ++j)
		{
			if (increase_j != 0)
			{
				verific_j = 0;
				for (int m = increase_k; m < increase_k + increase_j; ++m)
				{
					if (j == k_f[m])
					{

						for (k = 0; k < _size_z; ++k)
						{
							verific_k = 0;
							for (int n = 0; n < increase_k; ++n)
							{
								if (k == k_f[n])
								{
									value = data[i + j * _size_x + k * _size_x * _size_y];
									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									a = data[i + j * _size_x + k *_size_x * _size_y];
									b =
											data[i + j * _size_x
													+ (k + 1) *_size_x * _size_y];

									value = a + t_f[n] * (b - a);

									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									verific_k = 1;
								}
							}

							if (verific_k == 0)
							{
								a = data[i + j * _size_x + k *_size_x * _size_y];
								byte = reinterpret_cast<char*>(&value);
								fileISO.write(byte, sizeof(float));
							}
						}

						for (k = 0; k < _size_z; ++k)
						{
							verific_k = 0;
							for (int n = 0; n < increase_k; ++n)
							{
								if (k == k_f[n])
								{
									a = data[i + j * _size_x + k * _size_x * _size_y];
									b =
											data[i + (j + 1) * _size_x
													+ k * _size_x * _size_y];

									float value1 = a + t_f[m] * (b - a);
									byte = reinterpret_cast<char*>(&value1);
									fileISO.write(byte, sizeof(float));

									a =
											data[i + j * _size_x
													+ (k + 1) * _size_x * _size_y];
									b = data[i + (j + 1) * _size_x
											+ (k + 1) * _size_x * _size_y];

									float value2 = a + t_f[m] * (b - a);

									value = value1
											+ t_f[n] * (value2 - value1);

									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									verific_k = 1;
								}
							}

							if (verific_k == 0)
							{
								a = data[i + j * _size_x + k * _size_x * _size_y];
								b = data[i + (j + 1) * _size_x + k * _size_x * _size_y];

								value = a + t_f[m] * (b - a);
								byte = reinterpret_cast<char*>(&value);
								fileISO.write(byte, sizeof(float));
							}
						}

						verific_j = 1;
					}
				}
			}
			if (verific_j == 0)
			{
				for (k = 0; k < _size_z; ++k)
				{
					verific_k = 0;
					for (int n = 0; n < increase_k; ++n)
					{
						if (k == k_f[n])
						{
							value = data[i + j * _size_x + k * _size_x * _size_y];
							byte = reinterpret_cast<char*>(&value);
							fileISO.write(byte, sizeof(float));

							a = data[i + j * _size_x + k * _size_x * _size_y];
							b = data[i + j * _size_x + (k + 1) * _size_x * _size_y];

							value = a + t_f[n] * (b - a);

							byte = reinterpret_cast<char*>(&value);
							fileISO.write(byte, sizeof(float));

							verific_k = 1;
						}
					}

					if (verific_k == 0)
					{
						value = data[i + j * _size_x + k * _size_x * _size_y];
						byte = reinterpret_cast<char*>(&value);
						fileISO.write(byte, sizeof(float));
					}
				}
			}
		}

	return 0;
}
//====================================================================
int isoWriter::IsoSubdivide_u(const std::string fileName)
{

	unsigned char *data = new unsigned char[_n_data];
	data = _data_u;

	std::string isoFileName = fileName + ".iso";
	char* byte;

	std::ofstream fileISO(isoFileName.c_str(),
			std::ios::out | std::ios::binary);

	if (!fileISO.is_open())
	{
		std::cout << std::endl;
		std::cout << "\tCouldn't create specified file '" << isoFileName;
		std::cout << "'." << std::endl;
		return 1;
	}

    int increase_k = contk;
    int increase_j = contj;

	unsigned nz_ = _size_z + increase_k;
	unsigned ny_ = _size_y + increase_j;

	float mnx = 0.0, mny = 0.0, mnz = 0.0, mxx = _size_x * _sx, mxy = _size_y * _sy,
			mxz = _size_z * _sz;

	byte = reinterpret_cast<char*>(&_size_x);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&ny_);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&nz_);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&(mnx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mny));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxy));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mnz));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxz));
	fileISO.write(byte, sizeof(float));

	int verific_k = 0;
	int verific_j = 0;
	double a, b;
	float value;
	int i, j, k;

	for (i = 0; i < _size_x; ++i)
		for (j = 0; j < _size_y; ++j)
		{
			if (increase_j != 0)
			{
				verific_j = 0;
				for (int m = increase_k; m < increase_k + increase_j; ++m)
				{
					if (j == k_f[m])
					{

						for (k = 0; k < _size_z; ++k)
						{
							verific_k = 0;
							for (int n = 0; n < increase_k; ++n)
							{
								if (k == k_f[n])
								{
									value = data[i + j * _size_x + k * _size_x * _size_y];
									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									a = data[i + j * _size_x + k *_size_x * _size_y];
									b =
											data[i + j * _size_x
													+ (k + 1) *_size_x * _size_y];

									value = a + t_f[n] * (b - a);

									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									verific_k = 1;
								}
							}

							if (verific_k == 0)
							{
								a = data[i + j * _size_x + k *_size_x * _size_y];
								byte = reinterpret_cast<char*>(&value);
								fileISO.write(byte, sizeof(float));
							}
						}

						for (k = 0; k < _size_z; ++k)
						{
							verific_k = 0;
							for (int n = 0; n < increase_k; ++n)
							{
								if (k == k_f[n])
								{
									a = data[i + j * _size_x + k * _size_x * _size_y];
									b =
											data[i + (j + 1) * _size_x
													+ k * _size_x * _size_y];

									float value1 = a + t_f[m] * (b - a);
									byte = reinterpret_cast<char*>(&value1);
									fileISO.write(byte, sizeof(float));

									a =
											data[i + j * _size_x
													+ (k + 1) * _size_x * _size_y];
									b = data[i + (j + 1) * _size_x
											+ (k + 1) * _size_x * _size_y];

									float value2 = a + t_f[m] * (b - a);

									value = value1
											+ t_f[n] * (value2 - value1);

									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									verific_k = 1;
								}
							}

							if (verific_k == 0)
							{
								a = data[i + j * _size_x + k * _size_x * _size_y];
								b = data[i + (j + 1) * _size_x + k * _size_x * _size_y];

								value = a + t_f[m] * (b - a);
								byte = reinterpret_cast<char*>(&value);
								fileISO.write(byte, sizeof(float));
							}
						}

						verific_j = 1;
					}
				}
			}
			if (verific_j == 0)
			{
				for (k = 0; k < _size_z; ++k)
				{
					verific_k = 0;
					for (int n = 0; n < increase_k; ++n)
					{
						if (k == k_f[n])
						{
							value = data[i + j * _size_x + k * _size_x * _size_y];
							byte = reinterpret_cast<char*>(&value);
							fileISO.write(byte, sizeof(float));

							a = data[i + j * _size_x + k * _size_x * _size_y];
							b = data[i + j * _size_x + (k + 1) * _size_x * _size_y];

							value = a + t_f[n] * (b - a);

							byte = reinterpret_cast<char*>(&value);
							fileISO.write(byte, sizeof(float));

							verific_k = 1;
						}
					}

					if (verific_k == 0)
					{
						value = data[i + j * _size_x + k * _size_x * _size_y];
						byte = reinterpret_cast<char*>(&value);
						fileISO.write(byte, sizeof(float));
					}
				}
			}
		}

	return 0;
}
//================================================================================
int isoWriter::IsoSubdivide_s(const std::string fileName)
{

	short *data = new short [_n_data];
	data = _data_s;

	std::string isoFileName = fileName + ".iso";
	char* byte;

	std::ofstream fileISO(isoFileName.c_str(),
			std::ios::out | std::ios::binary);

	if (!fileISO.is_open())
	{
		std::cout << std::endl;
		std::cout << "\tCouldn't create specified file '" << isoFileName;
		std::cout << "'." << std::endl;
		return 1;
	}

    int increase_k = contk;
    int increase_j = contj;

	unsigned nz_ = _size_z + increase_k;
	unsigned ny_ = _size_y + increase_j;

	float mnx = 0.0, mny = 0.0, mnz = 0.0, mxx = _size_x * _sx, mxy = _size_y * _sy,
			mxz = _size_z * _sz;

	byte = reinterpret_cast<char*>(&_size_x);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&ny_);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&nz_);
	fileISO.write(byte, sizeof(unsigned));

	byte = reinterpret_cast<char*>(&(mnx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxx));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mny));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxy));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mnz));
	fileISO.write(byte, sizeof(float));
	byte = reinterpret_cast<char*>(&(mxz));
	fileISO.write(byte, sizeof(float));

	int verific_k = 0;
	int verific_j = 0;
	double a, b;
	float value;
	int i, j, k;

	for (i = 0; i < _size_x; ++i)
		for (j = 0; j < _size_y; ++j)
		{
			if (increase_j != 0)
			{
				verific_j = 0;
				for (int m = increase_k; m < increase_k + increase_j; ++m)
				{
					if (j == k_f[m])
					{

						for (k = 0; k < _size_z; ++k)
						{
							verific_k = 0;
							for (int n = 0; n < increase_k; ++n)
							{
								if (k == k_f[n])
								{
									value = data[i + j * _size_x + k * _size_x * _size_y];
									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									a = data[i + j * _size_x + k *_size_x * _size_y];
									b =
											data[i + j * _size_x
													+ (k + 1) *_size_x * _size_y];

									value = a + t_f[n] * (b - a);

									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									verific_k = 1;
								}
							}

							if (verific_k == 0)
							{
								a = data[i + j * _size_x + k *_size_x * _size_y];
								byte = reinterpret_cast<char*>(&value);
								fileISO.write(byte, sizeof(float));
							}
						}

						for (k = 0; k < _size_z; ++k)
						{
							verific_k = 0;
							for (int n = 0; n < increase_k; ++n)
							{
								if (k == k_f[n])
								{
									a = data[i + j * _size_x + k * _size_x * _size_y];
									b =
											data[i + (j + 1) * _size_x
													+ k * _size_x * _size_y];

									float value1 = a + t_f[m] * (b - a);
									byte = reinterpret_cast<char*>(&value1);
									fileISO.write(byte, sizeof(float));

									a =
											data[i + j * _size_x
													+ (k + 1) * _size_x * _size_y];
									b = data[i + (j + 1) * _size_x
											+ (k + 1) * _size_x * _size_y];

									float value2 = a + t_f[m] * (b - a);

									value = value1
											+ t_f[n] * (value2 - value1);

									byte = reinterpret_cast<char*>(&value);
									fileISO.write(byte, sizeof(float));

									verific_k = 1;
								}
							}

							if (verific_k == 0)
							{
								a = data[i + j * _size_x + k * _size_x * _size_y];
								b = data[i + (j + 1) * _size_x + k * _size_x * _size_y];

								value = a + t_f[m] * (b - a);
								byte = reinterpret_cast<char*>(&value);
								fileISO.write(byte, sizeof(float));
							}
						}

						verific_j = 1;
					}
				}
			}
			if (verific_j == 0)
			{
				for (k = 0; k < _size_z; ++k)
				{
					verific_k = 0;
					for (int n = 0; n < increase_k; ++n)
					{
						if (k == k_f[n])
						{
							value = data[i + j * _size_x + k * _size_x * _size_y];
							byte = reinterpret_cast<char*>(&value);
							fileISO.write(byte, sizeof(float));

							a = data[i + j * _size_x + k * _size_x * _size_y];
							b = data[i + j * _size_x + (k + 1) * _size_x * _size_y];

							value = a + t_f[n] * (b - a);

							byte = reinterpret_cast<char*>(&value);
							fileISO.write(byte, sizeof(float));

							verific_k = 1;
						}
					}

					if (verific_k == 0)
					{
						value = data[i + j * _size_x + k * _size_x * _size_y];
						byte = reinterpret_cast<char*>(&value);
						fileISO.write(byte, sizeof(float));
					}
				}
			}
		}

	return 0;
}
#endif /* ISOWRITER_HPP_ */
